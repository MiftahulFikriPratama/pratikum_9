<?php
class dosen_model extends CI_Model {
 // lengkapi
 public $id;
 public $nama;
 public $nidn;
 public $gender;
 public $tmp_lahir;
 public $tgl_lahir;
 public $pendidikan;
}
?>